package com.romanzhigachev.m74can

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class Metrics(
    val rpm: Double = 0.0,
    val speed: Double = 0.0,
    val coolant: Double = 0.0,
    val voltage: Double = 0.0,
    val map: Double = 0.0,
    val throttle: Double = 0.0,
    val intake: Double = 0.0,
    val timing: Double = 0.0
)

class MainActivity : ComponentActivity() {

    private val permissions =
        registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissions.launch(
                arrayOf(
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_SCAN
                )
            )
        }

        setContent {
            App()
        }
    }
}

@SuppressLint("MissingPermission")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val adapter = remember { BluetoothAdapter.getDefaultAdapter() }
    val client = remember { Elm327Client() }
    val scope = rememberCoroutineScope()

    var connected by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Нет подключения") }
    var metrics by remember { mutableStateOf(Metrics()) }
    var dtcs by remember { mutableStateOf(emptyList<String>()) }
    var log by remember { mutableStateOf("") }
    var raw by remember { mutableStateOf("") }
    var tab by remember { mutableIntStateOf(0) }
    var devices by remember { mutableStateOf(emptyList<BluetoothDevice>()) }
    var dialog by remember { mutableStateOf(false) }

    fun choose() {
        devices = adapter?.bondedDevices?.sortedBy { it.name ?: "" } ?: emptyList()
        dialog = true
    }

    fun connect(device: BluetoothDevice) {
        scope.launch {
            try {
                status = "Подключение..."
                val result = client.connect(device)
                connected = true
                status = "Подключено: ${device.name ?: device.address}"
                log += "ELM: $result\n"
            } catch (e: Exception) {
                connected = false
                status = "Ошибка: ${e.message ?: "неизвестная ошибка"}"
            }
        }
    }

    fun poll() {
        scope.launch {
            try {
                val rpm = client.command("010C")
                val speed = client.command("010D")
                val coolant = client.command("0105")
                val voltage = client.command("0142")
                val map = client.command("010B")
                val throttle = client.command("0111")
                val intake = client.command("010F")
                val timing = client.command("010E")

                metrics = Metrics(
                    rpm = ObdParser.rpm(rpm) ?: metrics.rpm,
                    speed = ObdParser.speed(speed) ?: metrics.speed,
                    coolant = ObdParser.coolant(coolant) ?: metrics.coolant,
                    voltage = ObdParser.voltage(voltage) ?: metrics.voltage,
                    map = ObdParser.map(map) ?: metrics.map,
                    throttle = ObdParser.throttle(throttle) ?: metrics.throttle,
                    intake = ObdParser.intake(intake) ?: metrics.intake,
                    timing = ObdParser.timing(timing) ?: metrics.timing
                )
            } catch (_: Exception) {
                connected = false
                status = "Связь потеряна"
            }
        }
    }

    LaunchedEffect(connected) {
        while (connected) {
            poll()
            delay(1000)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("M74CAN Diagnostic") })
        },
        bottomBar = {
            NavigationBar {
                val tabs = listOf(
                    "Параметры",
                    "Ошибки",
                    "Графики",
                    "RAW",
                    "Подключение"
                )
                tabs.forEachIndexed { index, name ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { tab = index },
                        icon = {},
                        label = { Text(name) }
                    )
                }
            }
        }
    ) { padding ->
        when (tab) {
            0 -> {
                LazyColumn(
                    modifier = Modifier.padding(padding).padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        Text(
                            if (connected) "🟢 ELM327 подключён" else "🔴 Нет подключения",
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    item { Text(status) }
                    item { Metric("Обороты", "%.0f об/мин".format(metrics.rpm)) }
                    item { Metric("Скорость", "%.0f км/ч".format(metrics.speed)) }
                    item { Metric("Температура ОЖ", "%.1f °C".format(metrics.coolant)) }
                    item { Metric("Напряжение", "%.2f В".format(metrics.voltage)) }
                    item { Metric("MAP", "%.0f kPa".format(metrics.map)) }
                    item { Metric("Дроссель", "%.1f %%".format(metrics.throttle)) }
                    item { Metric("Температура воздуха", "%.1f °C".format(metrics.intake)) }
                    item { Metric("Угол зажигания", "%.1f °".format(metrics.timing)) }
                }
            }

            1 -> {
                Column(
                    modifier = Modifier.padding(padding).padding(12.dp)
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            enabled = connected,
                            onClick = {
                                scope.launch {
                                    try {
                                        val result = client.command("03", 2500)
                                        dtcs = ObdParser.dtc(result)
                                        log += "TX 03\nRX $result\n"
                                    } catch (e: Exception) {
                                        log += "Ошибка: ${e.message}\n"
                                    }
                                }
                            }
                        ) { Text("Прочитать") }

                        OutlinedButton(
                            enabled = connected,
                            onClick = {
                                scope.launch {
                                    try {
                                        val result = client.command("04", 2500)
                                        dtcs = emptyList()
                                        log += "TX 04\nRX $result\n"
                                    } catch (e: Exception) {
                                        log += "Ошибка: ${e.message}\n"
                                    }
                                }
                            }
                        ) { Text("Очистить") }
                    }

                    Spacer(Modifier.height(12.dp))

                    LazyColumn {
                        items(dtcs.size) { index ->
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(4.dp)
                            ) {
                                Text(dtcs[index], Modifier.padding(16.dp))
                            }
                        }
                    }
                }
            }

            2 -> {
                Column(Modifier.padding(padding).padding(16.dp)) {
                    Text("Графики", style = MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.height(8.dp))
                    Text("История параметров")
                    Text("RPM: %.0f".format(metrics.rpm))
                    Text("ОЖ: %.1f °C".format(metrics.coolant))
                    Text("Напряжение: %.2f В".format(metrics.voltage))
                }
            }

            3 -> {
                Column(Modifier.padding(padding).padding(12.dp)) {
                    Row {
                        OutlinedTextField(
                            value = raw,
                            onValueChange = { raw = it },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            label = { Text("Команда OBD") }
                        )
                        Button(
                            onClick = {
                                scope.launch {
                                    if (raw.isNotBlank()) {
                                        try {
                                            val command = raw
                                            val result = client.command(command, 3000)
                                            log += "TX $command\nRX $result\n"
                                            raw = ""
                                        } catch (e: Exception) {
                                            log += "Ошибка: ${e.message}\n"
                                        }
                                    }
                                }
                            }
                        ) { Text("→") }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        log.ifEmpty {
                            "RAW лог пуст.\nПримеры: ATI, ATDP, 010C, 0105, 03"
                        }
                    )
                }
            }

            4 -> {
                Column(
                    modifier = Modifier.padding(padding).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("Bluetooth ELM327", style = MaterialTheme.typography.headlineSmall)
                    Text(status)

                    if (!connected) {
                        Button(onClick = { choose() }) {
                            Text("Выбрать Bluetooth-адаптер")
                        }
                    } else {
                        OutlinedButton(
                            onClick = {
                                client.close()
                                connected = false
                                status = "Отключено"
                            }
                        ) { Text("Отключить") }
                    }

                    Text(
                        "Сначала сопряги OBDII в системных настройках Android. " +
                            "Затем выбери его здесь."
                    )
                }
            }
        }
    }

    if (dialog) {
        AlertDialog(
            onDismissRequest = { dialog = false },
            title = { Text("Сопряжённые устройства") },
            text = {
                Column {
                    if (devices.isEmpty()) {
                        Text("Нет сопряжённых устройств.")
                    }
                    devices.forEach { device ->
                        TextButton(
                            onClick = {
                                connect(device)
                                dialog = false
                            }
                        ) {
                            Text(device.name ?: device.address)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { dialog = false }) {
                    Text("Закрыть")
                }
            }
        )
    }
}

@Composable
fun Metric(title: String, value: String) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(title)
            Text(value)
        }
    }
}
