package com.romanzhigachev.m74can

object ObdParser {
    private fun bytes(s: String) = s.uppercase()
        .replace(Regex("[^0-9A-F ]"), " ").split(Regex("\s+"))
        .filter { it.matches(Regex("[0-9A-F]{2}")) }.map { it.toInt(16) }

    private fun data(s: String, pid: Int): List<Int>? {
        val b = bytes(s)
        val i = b.indexOfFirst { it == 0x41 }
        return if (i >= 0 && i + 1 < b.size && b[i + 1] == pid) b.drop(i + 2) else null
    }

    fun rpm(s: String) = data(s, 0x0C)?.let { if (it.size >= 2) (it[0]*256+it[1])/4.0 else null }
    fun speed(s: String) = data(s, 0x0D)?.firstOrNull()?.toDouble()
    fun coolant(s: String) = data(s, 0x05)?.firstOrNull()?.minus(40.0)
    fun map(s: String) = data(s, 0x0B)?.firstOrNull()?.toDouble()
    fun throttle(s: String) = data(s, 0x11)?.firstOrNull()?.times(100.0)?.div(255.0)
    fun intake(s: String) = data(s, 0x0F)?.firstOrNull()?.minus(40.0)
    fun voltage(s: String) = data(s, 0x42)?.let { if (it.size >= 2) (it[0]*256+it[1])/1000.0 else null }
    fun timing(s: String) = data(s, 0x0E)?.firstOrNull()?.let { (it-64)/2.0 }

    fun dtc(s: String): List<String> {
        val b = bytes(s); val i = b.indexOf(0x43); if (i < 0) return emptyList()
        val out = mutableListOf<String>(); var p=i+1
        while (p+1 < b.size) {
            val a=b[p]; val c=b[p+1]; if (a==0 && c==0) break
            val prefix = "PCBU"[(a shr 6) and 3]
            out += "$prefix${(a shr 4) and 3}${"%X".format(a and 15)}${"%X".format(c shr 4)}${"%X".format(c and 15)}"
            p += 2
        }
        return out
    }
}
