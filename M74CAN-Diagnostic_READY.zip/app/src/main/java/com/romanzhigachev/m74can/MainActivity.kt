package com.romanzhigachev.m74can

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class Metrics(val rpm:Double=0.0,val speed:Double=0.0,val coolant:Double=0.0,val voltage:Double=0.0,val map:Double=0.0,val throttle:Double=0.0,val intake:Double=0.0,val timing:Double=0.0)

class MainActivity: ComponentActivity() {
    private val perms=registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){}
    override fun onCreate(b:Bundle?) {
        super.onCreate(b)
        if(Build.VERSION.SDK_INT>=31) perms.launch(arrayOf(Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN))
        setContent { App() }
    }
}

@SuppressLint("MissingPermission")
@Composable fun App() {
    val adapter=remember{BluetoothAdapter.getDefaultAdapter()}
    val client=remember{Elm327Client()}
    val scope=rememberCoroutineScope()
    var connected by remember{mutableStateOf(false)}
    var status by remember{mutableStateOf("Нет подключения")}
    var metrics by remember{mutableStateOf(Metrics())}
    var dtcs by remember{mutableStateOf(listOf<String>())}
    var log by remember{mutableStateOf("")}
    var raw by remember{mutableStateOf("")}
    var tab by remember{mutableIntStateOf(0)}
    var devices by remember{mutableStateOf(listOf<BluetoothDevice>())}
    var dialog by remember{mutableStateOf(false)}

    fun choose(){ devices=adapter?.bondedDevices?.sortedBy{it.name?:""}?:emptyList(); dialog=true }
    fun connect(d:BluetoothDevice){ scope.launch{ try{status="Подключение…";val r=client.connect(d);connected=true;status="Подключено: ${d.name?:d.address}";log+="ELM: $r\n"}catch(e:Exception){connected=false;status="Ошибка: ${e.message}"}}}
    fun poll(){scope.launch{try{
        val r=client.command("010C"); val s=client.command("010D"); val c=client.command("0105"); val v=client.command("0142"); val m=client.command("010B"); val t=client.command("0111"); val i=client.command("010F"); val a=client.command("010E")
        metrics=Metrics(ObdParser.rpm(r)?:metrics.rpm,ObdParser.speed(s)?:metrics.speed,ObdParser.coolant(c)?:metrics.coolant,ObdParser.voltage(v)?:metrics.voltage,ObdParser.map(m)?:metrics.map,ObdParser.throttle(t)?:metrics.throttle,ObdParser.intake(i)?:metrics.intake,ObdParser.timing(a)?:metrics.timing)
    }catch(e:Exception){connected=false;status="Связь потеряна"}}}
    LaunchedEffect(connected){while(connected){poll();delay(1000)}}

    Scaffold(topBar={TopAppBar(title={Text("M74CAN Diagnostic")})},bottomBar={
        NavigationBar{listOf("Параметры","Ошибки","Графики","RAW","Подключение").forEachIndexed{i,n->
            NavigationBarItem(selected=tab==i,onClick={tab=i},icon={},label={Text(n)})
        }}
    }){pad->
        when(tab){
            0->LazyColumn(Modifier.padding(pad).padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                item{Text(if(connected)"🟢 ELM327 подключён" else "🔴 Нет подключения",style=MaterialTheme.typography.titleMedium)}
                item{Text(status)}
                item{Metric("Обороты","%.0f об/мин".format(metrics.rpm))}
                item{Metric("Скорость","%.0f км/ч".format(metrics.speed))}
                item{Metric("Температура ОЖ","%.1f °C".format(metrics.coolant))}
                item{Metric("Напряжение","%.2f В".format(metrics.voltage))}
                item{Metric("MAP","%.0f kPa".format(metrics.map))}
                item{Metric("Дроссель","%.1f %%".format(metrics.throttle))}
                item{Metric("Температура воздуха","%.1f °C".format(metrics.intake))}
                item{Metric("Угол зажигания","%.1f °".format(metrics.timing))}
            }
            1->Column(Modifier.padding(pad).padding(12.dp)){
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(enabled=connected,onClick={scope.launch{val r=client.command("03",2500);dtcs=ObdParser.dtc(r);log+="TX 03\nRX $r\n"}}){Text("Прочитать")};OutlinedButton(enabled=connected,onClick={scope.launch{val r=client.command("04",2500);dtcs=emptyList();log+="TX 04\nRX $r\n"}}){Text("Очистить")}}
                Spacer(Modifier.height(12.dp)); LazyColumn{items(dtcs.size){i->Card(Modifier.fillMaxWidth().padding(4.dp)){Text(dtcs[i],Modifier.padding(16.dp))}}}
            }
            2->Column(Modifier.padding(pad).padding(16.dp)){Text("Графики",style=MaterialTheme.typography.headlineSmall);Text("Буфер истории будет добавлен в следующую сборку.");Text("RPM: %.0f".format(metrics.rpm));Text("ОЖ: %.1f °C".format(metrics.coolant));Text("Напряжение: %.2f В".format(metrics.voltage))}
            3->Column(Modifier.padding(pad).padding(12.dp)){
                Row{OutlinedTextField(raw,{raw=it},Modifier.weight(1f),singleLine=true);Button(onClick={scope.launch{if(raw.isNotBlank()){val r=client.command(raw,3000);log+="TX $raw\nRX $r\n";raw=""}}}){Text("→")}}
                Spacer(Modifier.height(8.dp));Text(log.ifEmpty{"RAW лог пуст. Примеры: ATI, ATDP, 010C, 0105, 03"})
            }
            4->Column(Modifier.padding(pad).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
                Text("Bluetooth ELM327",style=MaterialTheme.typography.headlineSmall);Text(status)
                if(!connected) Button(onClick={choose}){Text("Выбрать Bluetooth-адаптер")}
                else OutlinedButton(onClick={client.close();connected=false;status="Отключено"}){Text("Отключить")}
                Text("Сначала сопряги OBDII в системных настройках Android. Затем выбери его здесь.")
            }
        }
    }
    if(dialog) AlertDialog(onDismissRequest={dialog=false},title={Text("Сопряжённые устройства")},text={Column{if(devices.isEmpty())Text("Нет сопряжённых устройств.");devices.forEach{d->TextButton(onClick={connect(d);dialog=false}){Text(d.name?:d.address)}}}},confirmButton={TextButton(onClick={dialog=false}){Text("Закрыть")}})
}

@Composable fun Metric(t:String,v:String){Card(Modifier.fillMaxWidth()){Row(Modifier.padding(16.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(t);Text(v)}}}
