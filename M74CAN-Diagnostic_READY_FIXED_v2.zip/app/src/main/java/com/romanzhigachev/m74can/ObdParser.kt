package com.romanzhigachev.m74can

/**
 * OBD-II response parser.
 *
 * ELM327 can be configured with ATS0 (no spaces), so responses may look like:
 *   7E804410C0D4C
 * or with spaces/line breaks:
 *   7E8 04 41 0C 0D 4C
 *
 * We therefore parse hexadecimal byte pairs from each response instead of
 * requiring whitespace-separated bytes.
 */
object ObdParser {
    private fun bytes(s: String): List<Int> {
        val hex = s.uppercase().replace(Regex("[^0-9A-F]"), "")
        if (hex.length < 2) return emptyList()

        // Ignore a possible single trailing nibble from malformed text.
        val evenHex = if (hex.length % 2 == 0) hex else hex.dropLast(1)
        return evenHex.chunked(2).mapNotNull { it.toIntOrNull(16) }
    }

    /**
     * Finds a standard OBD response 41 <PID> and returns the PID data bytes.
     * CAN headers such as 7E8 and ISO-TP length bytes are intentionally ignored.
     */
    private fun data(s: String, pid: Int): List<Int>? {
        val b = bytes(s)
        for (i in 0 until b.size - 1) {
            if (b[i] == 0x41 && b[i + 1] == pid) {
                return b.drop(i + 2)
            }
        }
        return null
    }

    fun rpm(s: String): Double? = data(s, 0x0C)?.let {
        if (it.size >= 2) (it[0] * 256 + it[1]) / 4.0 else null
    }

    fun speed(s: String): Double? = data(s, 0x0D)?.firstOrNull()?.toDouble()

    fun coolant(s: String): Double? = data(s, 0x05)?.firstOrNull()?.minus(40.0)

    fun map(s: String): Double? = data(s, 0x0B)?.firstOrNull()?.toDouble()

    fun throttle(s: String): Double? = data(s, 0x11)?.firstOrNull()?.times(100.0)?.div(255.0)

    fun intake(s: String): Double? = data(s, 0x0F)?.firstOrNull()?.minus(40.0)

    fun voltage(s: String): Double? = data(s, 0x42)?.let {
        if (it.size >= 2) (it[0] * 256 + it[1]) / 1000.0 else null
    }

    fun timing(s: String): Double? = data(s, 0x0E)?.firstOrNull()?.let {
        (it - 128) / 2.0
    }

    fun dtc(s: String): List<String> {
        val b = bytes(s)
        val i = b.indexOf(0x43)
        if (i < 0) return emptyList()

        val out = mutableListOf<String>()
        var p = i + 1
        while (p + 1 < b.size) {
            val a = b[p]
            val c = b[p + 1]
            if (a == 0 && c == 0) break

            val prefix = "PCBU"[(a shr 6) and 3]
            out += "$prefix${(a shr 4) and 3}${"%X".format(a and 15)}${"%X".format(c shr 4)}${"%X".format(c and 15)}"
            p += 2
        }
        return out
    }
}
