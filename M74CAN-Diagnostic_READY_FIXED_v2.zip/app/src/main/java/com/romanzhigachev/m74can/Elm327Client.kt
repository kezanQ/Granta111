package com.romanzhigachev.m74can

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

class Elm327Client {
    private val sppUuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val ioMutex = Mutex()
    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null

    @SuppressLint("MissingPermission")
    suspend fun connect(device: BluetoothDevice): String = withContext(Dispatchers.IO) {
        close()
        socket = device.createRfcommSocketToServiceRecord(sppUuid)
        socket!!.connect()
        input = socket!!.inputStream
        output = socket!!.outputStream

        command("ATZ", 2500)
        command("ATE0")
        // Keep spaces in responses. This makes the RAW log readable and also
        // gives the parser both spaced and unspaced response compatibility.
        command("ATS1")
        command("ATH1")
        command("ATSP6")
        command("ATAT1")
        command("ATI")
    }

    suspend fun command(cmd: String, timeout: Long = 1500): String = ioMutex.withLock {
        withContext(Dispatchers.IO) {
            val inp = input ?: error("Нет подключения")
            val out = output ?: error("Нет подключения")

            while (inp.available() > 0) inp.read()

            out.write((cmd.trim() + "\r").toByteArray(Charsets.US_ASCII))
            out.flush()

            val start = System.currentTimeMillis()
            val sb = StringBuilder()
            val buf = ByteArray(512)

            while (System.currentTimeMillis() - start < timeout) {
                if (inp.available() > 0) {
                    val n = inp.read(buf)
                    if (n > 0) {
                        sb.append(String(buf, 0, n, Charsets.US_ASCII))
                        if (sb.contains(">")) break
                    }
                } else {
                    Thread.sleep(10)
                }
            }

            sb.toString()
                .replace(">", "")
                .replace("\r", "\n")
                .replace(Regex("\n+"), "\n")
                .trim()
        }
    }

    fun close() {
        try { socket?.close() } catch (_: Exception) {}
        socket = null
        input = null
        output = null
    }
}
