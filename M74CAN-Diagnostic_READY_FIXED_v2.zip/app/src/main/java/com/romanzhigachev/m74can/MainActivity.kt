package com.romanzhigachev.m74can

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CarRepair
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin

private val Bg = Color(0xFF020812)
private val CardBg = Color(0xFF071321)
private val CardBg2 = Color(0xFF0A1828)
private val Border = Color(0xFF19334D)
private val TextPrimary = Color(0xFFF3F7FF)
private val TextSecondary = Color(0xFFAABBD2)
private val Green = Color(0xFF00E5A8)
private val Blue = Color(0xFF159DFF)
private val Red = Color(0xFFFF315E)
private val Orange = Color(0xFFFFB21A)
private val Purple = Color(0xFF9C5CFF)

private data class Metrics(
    val rpm: Double = 0.0,
    val speed: Double = 0.0,
    val coolant: Double = 0.0,
    val voltage: Double = 0.0,
    val map: Double = 0.0,
    val throttle: Double = 0.0,
    val intake: Double = 0.0,
    val timing: Double = 0.0
)

private data class Sample(val rpm: Float, val coolant: Float, val speed: Float, val throttle: Float)

class MainActivity : ComponentActivity() {
    private val permissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissions.launch(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN))
        }
        setContent { App() }
    }
}

@SuppressLint("MissingPermission")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun App() {
    val adapter = remember { BluetoothAdapter.getDefaultAdapter() }
    val client = remember { Elm327Client() }
    val scope = rememberCoroutineScope()

    var connected by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Нет подключения") }
    var metrics by remember { mutableStateOf(Metrics()) }
    var dtcs by remember { mutableStateOf(emptyList<String>()) }
    var log by remember { mutableStateOf("") }
    var rawCommand by remember { mutableStateOf("") }
    var tab by remember { mutableIntStateOf(0) }
    var devices by remember { mutableStateOf(emptyList<BluetoothDevice>()) }
    var dialog by remember { mutableStateOf(false) }
    val history = remember { mutableStateListOf<Sample>() }

    fun choose() {
        devices = adapter?.bondedDevices?.sortedBy { it.name ?: "" } ?: emptyList()
        dialog = true
    }

    fun connect(device: BluetoothDevice) {
        scope.launch {
            try {
                status = "Подключение..."
                val result = client.connect(device)
                connected = true
                status = "Подключено: ${device.name ?: device.address}"
                log += "ELM: $result\n"
            } catch (e: Exception) {
                connected = false
                status = "Ошибка: ${e.message ?: "неизвестная ошибка"}"
            }
        }
    }

    fun parseElmVoltage(response: String): Double? = Regex("([0-9]+(?:\\.[0-9]+)?)\\s*V", RegexOption.IGNORE_CASE)
        .find(response)?.groupValues?.getOrNull(1)?.toDoubleOrNull()

    suspend fun poll() {
        try {
            val rpm = client.command("010C")
            val speed = client.command("010D")
            val coolant = client.command("0105")
            val voltagePid = client.command("0142")
            val voltageElm = client.command("ATRV")
            val map = client.command("010B")
            val throttle = client.command("0111")
            val intake = client.command("010F")
            val timing = client.command("010E")
            metrics = Metrics(
                rpm = ObdParser.rpm(rpm) ?: metrics.rpm,
                speed = ObdParser.speed(speed) ?: metrics.speed,
                coolant = ObdParser.coolant(coolant) ?: metrics.coolant,
                voltage = ObdParser.voltage(voltagePid) ?: parseElmVoltage(voltageElm) ?: metrics.voltage,
                map = ObdParser.map(map) ?: metrics.map,
                throttle = ObdParser.throttle(throttle) ?: metrics.throttle,
                intake = ObdParser.intake(intake) ?: metrics.intake,
                timing = ObdParser.timing(timing) ?: metrics.timing
            )
            history.add(Sample(metrics.rpm.toFloat(), metrics.coolant.toFloat(), metrics.speed.toFloat(), metrics.throttle.toFloat()))
            while (history.size > 32) history.removeAt(0)
            log = (log + "RPM=$rpm | SPD=$speed | ECT=$coolant | MAP=$map | TPS=$throttle | IAT=$intake\n").takeLast(7000)
        } catch (e: Exception) {
            connected = false
            status = "Связь потеряна: ${e.message ?: "ошибка обмена"}"
        }
    }

    LaunchedEffect(connected) {
        while (connected) {
            poll()
            delay(1000)
        }
    }

    MaterialTheme(colorScheme = darkScheme()) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("M74CAN", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 23.sp)
                            Text("Диагностика ЭБУ M74CAN", color = TextSecondary, fontSize = 13.sp)
                        }
                    },
                    navigationIcon = { IconButton(onClick = {}) { Icon(Icons.Default.Menu, null, tint = TextPrimary) } },
                    actions = {
                        Surface(
                            shape = RoundedCornerShape(22.dp),
                            color = Color(0x3300E5A8),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x6600E5A8))
                        ) {
                            Row(Modifier.padding(horizontal = 14.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(9.dp).clip(CircleShape).background(if (connected) Green else Red))
                                Spacer(Modifier.width(8.dp))
                                Column {
                                    Text("ELM327", color = TextSecondary, fontSize = 12.sp)
                                    Text(if (connected) "Подключен" else "Не подключен", color = if (connected) Green else Red, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(Modifier.width(8.dp))
                                Icon(Icons.Default.Bluetooth, null, tint = if (connected) Green else TextSecondary)
                            }
                        }
                        Spacer(Modifier.width(10.dp))
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF06101D), modifier = Modifier.navigationBarsPadding()) {
                    val tabs = listOf(
                        Triple("Параметры", Icons.Default.CarRepair, 0),
                        Triple("Ошибки", Icons.Default.ErrorOutline, 1),
                        Triple("Графики", Icons.Default.ShowChart, 2),
                        Triple("RAW", Icons.Default.Description, 3),
                        Triple("Подключение", Icons.Default.Link, 4)
                    )
                    tabs.forEach { (name, icon, index) ->
                        NavigationBarItem(
                            selected = tab == index,
                            onClick = { tab = index },
                            icon = { Icon(icon, null) },
                            label = { Text(name, fontSize = 10.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            when (tab) {
                0 -> Dashboard(Modifier.padding(padding), connected, metrics, history)
                1 -> ErrorsScreen(Modifier.padding(padding), connected, client, scope, dtcs) { dtcs = it; log += "DTC обновлены\n" }
                2 -> GraphScreen(Modifier.padding(padding), history, metrics)
                3 -> RawScreen(Modifier.padding(padding), rawCommand, { rawCommand = it }, connected, client, scope, log) { log += it }
                4 -> ConnectionScreen(Modifier.padding(padding), connected, status, { choose() }, { client.close(); connected = false; status = "Отключено" })
            }
        }
    }

    if (dialog) {
        AlertDialog(
            onDismissRequest = { dialog = false },
            title = { Text("Сопряжённые устройства") },
            text = {
                Column {
                    if (devices.isEmpty()) Text("Нет сопряжённых устройств.")
                    devices.forEach { device ->
                        TextButton(onClick = { connect(device); dialog = false }) { Text(device.name ?: device.address) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { dialog = false }) { Text("Закрыть") } }
        )
    }
}

@Composable
private fun Dashboard(modifier: Modifier, connected: Boolean, m: Metrics, history: List<Sample>) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 18.dp)) {
        item { HeroCard(connected, m) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                TelemetryCard("Скорость", "%.0f".format(m.speed), "км/ч", Blue, Icons.Default.Speed, Modifier.weight(1f))
                TelemetryCard("Температура ОЖ", "%.0f".format(m.coolant), "°C", Red, Icons.Default.Thermostat, Modifier.weight(1f))
                TelemetryCard("Напряжение", "%.1f".format(m.voltage), "В", Green, Icons.Default.Bolt, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                TelemetryCard("Дроссель", "%.1f".format(m.throttle), "%", Orange, Icons.Default.Tune, Modifier.weight(1f))
                TelemetryCard("Температура воздуха", "%.0f".format(m.intake), "°C", Blue, Icons.Default.Thermostat, Modifier.weight(1f))
                TelemetryCard("MAP", if (m.map > 0) "%.0f".format(m.map) else "—", "кПа", Purple, Icons.Default.Speed, Modifier.weight(1f))
            }
        }
        item { GraphCard(history, m) }
        item {
            Surface(shape = RoundedCornerShape(22.dp), color = Color(0x2210E5A8), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x4400E5A8)), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, null, tint = Green, modifier = Modifier.size(24.dp))
                    Spacer(Modifier.width(10.dp))
                    Text("Данные обновляются каждые 1 секунду", color = TextPrimary, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
private fun HeroCard(connected: Boolean, m: Metrics) {
    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = CardBg), border = androidx.compose.foundation.BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp).height(300.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1.1f).fillMaxHeight(), contentAlignment = Alignment.Center) { RpmGauge(m.rpm) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f).fillMaxHeight().padding(vertical = 10.dp), verticalArrangement = Arrangement.Center) {
                Image(painterResource(com.romanzhigachev.m74can.R.drawable.granta_drive_active), "Lada Granta Drive Active", Modifier.fillMaxWidth().height(115.dp), contentScale = ContentScale.Fit)
                Text("LADA GRANTA", color = TextPrimary, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("DRIVE ACTIVE", color = Color(0xFFB9C9E5), fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                ThinLine()
                InfoRow("Статус связи", if (connected) "OK" else "Нет", if (connected) Green else Red)
                InfoRow("Протокол", "CAN (11 bit)", TextPrimary)
                InfoRow("Скорость CAN", "500 кбит/с", TextPrimary)
            }
        }
    }
}

@Composable
private fun RpmGauge(rpm: Double) {
    Box(Modifier.size(250.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 18f
            val diameter = size.minDimension - 24f
            val topLeft = Offset((size.width - diameter) / 2, (size.height - diameter) / 2)
            val sweep = 255f
            drawArc(color = Color(0xFF173047), startAngle = 142f, sweepAngle = sweep, useCenter = false, topLeft = topLeft, size = Size(diameter, diameter), style = Stroke(width = stroke, cap = StrokeCap.Round))
            val fraction = (rpm / 8000.0).coerceIn(0.0, 1.0).toFloat()
            drawArc(color = Green, startAngle = 142f, sweepAngle = sweep * fraction, useCenter = false, topLeft = topLeft, size = Size(diameter, diameter), style = Stroke(width = stroke, cap = StrokeCap.Round))
            drawArc(color = Red, startAngle = 142f + sweep * 0.86f, sweepAngle = sweep * 0.14f, useCenter = false, topLeft = topLeft, size = Size(diameter, diameter), style = Stroke(width = stroke, cap = StrokeCap.Round))
            for (i in 0..8) {
                val a = Math.toRadians((142 + i * 31.875).toDouble())
                val r1 = diameter / 2 - 34
                val r2 = diameter / 2 - 17
                val cx = size.width / 2
                val cy = size.height / 2
                drawLine(start = Offset(cx + cos(a).toFloat() * r1, cy + sin(a).toFloat() * r1), end = Offset(cx + cos(a).toFloat() * r2, cy + sin(a).toFloat() * r2), color = TextSecondary, strokeWidth = 2f)
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("%.0f".format(rpm), color = TextPrimary, fontSize = 48.sp, fontWeight = FontWeight.Black)
            Text("об/мин", color = TextSecondary, fontSize = 17.sp)
            Spacer(Modifier.height(14.dp))
            Text("RPM", color = TextSecondary, fontSize = 14.sp)
            Icon(Icons.Default.CarRepair, null, tint = Green, modifier = Modifier.size(28.dp))
        }
    }
}

@Composable
private fun TelemetryCard(title: String, value: String, unit: String, accent: Color, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Card(modifier, shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = CardBg), border = androidx.compose.foundation.BorderStroke(1.dp, Border)) {
        Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.Start) {
            Box(Modifier.size(40.dp).clip(CircleShape).background(accent.copy(alpha = .13f)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = accent) }
            Spacer(Modifier.height(8.dp))
            Text(title, color = TextSecondary, fontSize = 12.sp, maxLines = 2)
            Spacer(Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(value, color = TextPrimary, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(4.dp))
                Text(unit, color = TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(bottom = 4.dp))
            }
        }
    }
}

@Composable
private fun GraphCard(history: List<Sample>, m: Metrics) {
    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = CardBg), border = androidx.compose.foundation.BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column { Text("Графики", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("в реальном времени", color = TextSecondary, fontSize = 12.sp) }
                Text("Все параметры  ›", color = TextSecondary, fontSize = 12.sp)
            }
            Spacer(Modifier.height(12.dp))
            MiniChart(history)
            Spacer(Modifier.height(12.dp))
            LegendRow(Green, "Обороты", "%.0f об/мин".format(m.rpm))
            LegendRow(Red, "Темп. ОЖ", "%.0f °C".format(m.coolant))
            LegendRow(Blue, "Скорость", "%.0f км/ч".format(m.speed))
            LegendRow(Orange, "Дроссель", "%.1f %%".format(m.throttle))
        }
    }
}

@Composable
private fun MiniChart(history: List<Sample>) {
    Canvas(Modifier.fillMaxWidth().height(160.dp)) {
        for (i in 0..4) {
            val y = size.height * i / 4f
            drawLine(color = Color(0xFF183047), start = Offset(0f, y), end = Offset(size.width, y), strokeWidth = 1f)
        }
        fun path(values: List<Float>, max: Float): Path {
            val p = Path()
            if (values.isEmpty()) return p
            values.forEachIndexed { i, v ->
                val x = if (values.size == 1) 0f else size.width * i / (values.size - 1)
                val y = size.height - (v.coerceIn(0f, max) / max) * size.height
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
            return p
        }
        val r = history.map { it.rpm }
        val c = history.map { it.coolant }
        val s = history.map { it.speed }
        val t = history.map { it.throttle }
        drawPath(path(r, 8000f), Green, style = Stroke(3f, cap = StrokeCap.Round))
        drawPath(path(c, 120f), Red, style = Stroke(3f, cap = StrokeCap.Round))
        drawPath(path(s, 160f), Blue, style = Stroke(3f, cap = StrokeCap.Round))
        drawPath(path(t, 100f), Orange, style = Stroke(3f, cap = StrokeCap.Round))
    }
}

@Composable private fun LegendRow(color: Color, name: String, value: String) { Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(9.dp).clip(CircleShape).background(color)); Spacer(Modifier.width(8.dp)); Text(name, color = TextSecondary, modifier = Modifier.weight(1f)); Text(value, color = TextPrimary, fontWeight = FontWeight.Bold) } }
@Composable private fun InfoRow(name: String, value: String, color: Color) { Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(name, color = TextSecondary); Text(value, color = color, fontWeight = FontWeight.SemiBold) } }
@Composable private fun ThinLine() { Spacer(Modifier.fillMaxWidth().height(1.dp).background(Border)) }

@Composable
private fun ErrorsScreen(modifier: Modifier, connected: Boolean, client: Elm327Client, scope: kotlinx.coroutines.CoroutineScope, dtcs: List<String>, setDtcs: (List<String>) -> Unit) {
    Column(modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Ошибки ECU", color = TextPrimary, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(enabled = connected, onClick = { scope.launch { runCatching { setDtcs(ObdParser.dtc(client.command("03", 2500))) } } }) { Text("Прочитать") }
            OutlinedButton(enabled = connected, onClick = { scope.launch { client.command("04", 2500); setDtcs(emptyList()) } }) { Text("Очистить") }
        }
        if (dtcs.isEmpty()) Text("Коды неисправностей не отображены.", color = TextSecondary)
        dtcs.forEach { code -> Card(colors = CardDefaults.cardColors(containerColor = CardBg), border = androidx.compose.foundation.BorderStroke(1.dp, Border)) { Text(code, Modifier.padding(18.dp), color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold) } }
    }
}

@Composable
private fun GraphScreen(modifier: Modifier, history: List<Sample>, m: Metrics) { Column(modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) { Text("Графики", color = TextPrimary, fontSize = 25.sp, fontWeight = FontWeight.Bold); GraphCard(history, m) } }

@Composable
private fun RawScreen(modifier: Modifier, raw: String, setRaw: (String) -> Unit, connected: Boolean, client: Elm327Client, scope: kotlinx.coroutines.CoroutineScope, log: String, append: (String) -> Unit) {
    Column(modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("RAW / OBD", color = TextPrimary, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = raw, onValueChange = setRaw, modifier = Modifier.weight(1f), singleLine = true, label = { Text("Команда OBD") })
            Spacer(Modifier.width(8.dp))
            Button(enabled = connected, onClick = { if (raw.isNotBlank()) scope.launch { val c = raw; val result = runCatching { client.command(c, 3000) }.getOrElse { "Ошибка: ${it.message}" }; append("TX $c\nRX $result\n"); setRaw("") } }) { Text("→") }
        }
        Card(Modifier.fillMaxWidth().weight(1f), colors = CardDefaults.cardColors(containerColor = CardBg), border = androidx.compose.foundation.BorderStroke(1.dp, Border)) {
            Text(if (log.isBlank()) appendableHint(raw) else log, Modifier.padding(14.dp), color = TextSecondary)
        }
    }
}
private fun appendableHint(raw: String): String = if (raw.isBlank()) "Введите команду, например: ATI, ATDP, 010C, 0105, 03" else "Команда готова к отправке: $raw"

@Composable
private fun ConnectionScreen(modifier: Modifier, connected: Boolean, status: String, choose: () -> Unit, disconnect: () -> Unit) {
    Column(modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Подключение", color = TextPrimary, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = CardBg), border = androidx.compose.foundation.BorderStroke(1.dp, Border)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(12.dp).clip(CircleShape).background(if (connected) Green else Red)); Spacer(Modifier.width(10.dp)); Text(if (connected) "ELM327 подключён" else "ELM327 не подключён", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                Text(status, color = TextSecondary)
                if (!connected) Button(onClick = choose, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Bluetooth, null); Spacer(Modifier.width(8.dp)); Text("Выбрать Bluetooth-адаптер") }
                else OutlinedButton(onClick = disconnect, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Close, null); Spacer(Modifier.width(8.dp)); Text("Отключить") }
            }
        }
        Text("Сопряги OBDII в системных настройках Android, затем выбери адаптер здесь.", color = TextSecondary)
    }
}

private fun darkScheme() = androidx.compose.material3.darkColorScheme(primary = Green, secondary = Blue, background = Bg, surface = CardBg, onPrimary = Color.Black, onBackground = TextPrimary, onSurface = TextPrimary)
