# M74CAN Diagnostic — Android

Проект под твой ELM327 Bluetooth Classic, который в Android определяется как `OBDII`.

Реализовано:
- Bluetooth Classic RFCOMM/SPP;
- подключение к сопряжённому OBDII;
- ELM327 init: ATZ, ATE0, ATL0, ATS0, ATH1, ATSP6, ATAT1;
- онлайн PID: RPM, скорость, ОЖ, напряжение, MAP, дроссель, температура воздуха, угол зажигания;
- DTC Mode 03;
- очистка DTC Mode 04;
- RAW команды;
- Compose-интерфейс.

Сборка:
1. Открыть проект в Android Studio.
2. Дождаться Gradle Sync.
3. Build -> Build APK(s).
4. Установить app-debug.apk.
5. Сопрячь `OBDII` в Bluetooth Android.
6. В приложении открыть «Подключение» и выбрать OBDII.

Важно: расширенные заводские M74CAN-команды не выдумываются. Для OpenDiag-подобных параметров нужны реальные CAN request/response кадры твоего M74CAN.
