package com.romanzhigachev.m74can

/**
 * Robust OBD-II parser for ELM327 responses with CAN headers enabled.
 *
 * The ELM327 is configured with ATH1, so a normal response can be:
 *   7E8 04 41 0C 0D 14
 *
 * With ATS0 it can also be:
 *   7E804410C0D14
 *
 * IMPORTANT: a 3-digit CAN header such as 7E8 must NOT be split into
 * hexadecimal byte pairs. The previous parser did exactly that, turning
 * 7E8 04 ... into 7E 80 44 10 ..., so it could never find 41 <PID>.
 */
object ObdParser {
    private fun clean(s: String): String = s.uppercase()
        .replace("\u0000", "")
        .replace(Regex("[^0-9A-F]"), "")

    /** Return bytes from the first 41 <PID> response, ignoring CAN headers. */
    private fun data(s: String, pid: Int): List<Int>? {
        val hex = clean(s)
        val pidHex = "%02X".format(pid)
        val marker = "41$pidHex"
        val start = hex.indexOf(marker)
        if (start < 0) return null

        val payload = hex.substring(start + marker.length)
        val even = payload.length - (payload.length % 2)
        if (even <= 0) return emptyList()

        return payload.substring(0, even)
            .chunked(2)
            .mapNotNull { it.toIntOrNull(16) }
    }

    fun rpm(s: String): Double? = data(s, 0x0C)?.let {
        if (it.size >= 2) (it[0] * 256 + it[1]) / 4.0 else null
    }

    fun speed(s: String): Double? = data(s, 0x0D)?.firstOrNull()?.toDouble()

    fun coolant(s: String): Double? = data(s, 0x05)?.firstOrNull()?.minus(40.0)

    fun map(s: String): Double? = data(s, 0x0B)?.firstOrNull()?.toDouble()

    fun throttle(s: String): Double? = data(s, 0x11)?.firstOrNull()?.times(100.0)?.div(255.0)

    fun intake(s: String): Double? = data(s, 0x0F)?.firstOrNull()?.minus(40.0)

    fun voltage(s: String): Double? = data(s, 0x42)?.let {
        if (it.size >= 2) (it[0] * 256 + it[1]) / 1000.0 else null
    }

    fun timing(s: String): Double? = data(s, 0x0E)?.firstOrNull()?.let {
        (it - 128) / 2.0
    }

    fun dtc(s: String): List<String> {
        val hex = clean(s)
        val start = hex.indexOf("43")
        if (start < 0) return emptyList()
        val payload = hex.substring(start + 2)
        val out = mutableListOf<String>()
        var p = 0
        while (p + 3 < payload.length) {
            val a = payload.substring(p, p + 2).toIntOrNull(16) ?: break
            val b = payload.substring(p + 2, p + 4).toIntOrNull(16) ?: break
            if (a == 0 && b == 0) break

            val prefix = "PCBU"[(a shr 6) and 3]
            out += "$prefix${(a shr 4) and 3}${"%X".format(a and 15)}${"%X".format(b shr 4)}${"%X".format(b and 15)}"
            p += 4
        }
        return out
    }
}
